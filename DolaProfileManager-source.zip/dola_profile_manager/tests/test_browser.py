import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from app.browser_manager import BrowserManager, detect_browser


@pytest.mark.parametrize('browser,channel', [('Microsoft Edge', 'msedge'), ('Google Chrome', 'chrome')])
def test_channels_duplicate_launch_and_close(environment, browser, channel):
    db, _, profiles = environment; p = profiles.create('Test', browser)
    manager = BrowserManager(db, profiles)
    playwright = MagicMock(); context = MagicMock(); context.close = AsyncMock()
    playwright.chromium.launch_persistent_context = AsyncMock(return_value=context)
    manager.playwright = playwright
    async def run():
        with patch('app.browser_manager.detect_browser', return_value=Path('browser.exe')):
            assert await manager.launch(p) is context
            with pytest.raises(ValueError, match='already running'):
                await manager.launch(p)
            assert await manager.launch(p, reuse=True) is context
            with pytest.raises(ValueError, match="Close"):
                profiles.delete(p)
            with pytest.raises(ValueError, match="Close"):
                profiles.duplicate(p, "Forbidden")
            await manager.close(p)
            assert not manager.active(p.id)
    asyncio.run(run())
    arguments = playwright.chromium.launch_persistent_context.call_args.kwargs
    assert arguments['channel'] == channel and arguments['user_data_dir'] == str(p.path)
    assert arguments['headless'] is False
    assert arguments['args'] == ['--no-first-run', '--no-default-browser-check', '--disable-sync']
    assert '--disable-extensions' in arguments['ignore_default_args']


@pytest.mark.parametrize('browser', ['Microsoft Edge', 'Google Chrome'])
def test_missing_browser(environment, browser):
    db, _, profiles = environment; p = profiles.create('Test', browser)
    with patch('app.browser_manager.detect_browser', return_value=None):
        with pytest.raises(ValueError, match='not found'):
            asyncio.run(BrowserManager(db, profiles).launch(p))


def test_launch_all_opens_every_profile_and_reports_individual_failures(environment):
    db, _, profiles = environment
    first = profiles.create('Profile 001', 'Microsoft Edge')
    second = profiles.create('Profile 002', 'Google Chrome')
    manager = BrowserManager(db, profiles)

    async def run():
        with patch.object(manager, 'launch_and_open_dola', new=AsyncMock(side_effect=[None, ValueError('Google Chrome was not found on this computer.')])):
            opened, failures = await manager.launch_all_and_open_dola([first, second])
        assert opened == [first]
        assert failures == ['Profile 002: Google Chrome was not found on this computer.']

    asyncio.run(run())


def test_bulk_launch_starts_independent_profiles_concurrently(environment):
    """A slow profile must not hold up launch of another isolated profile."""
    db, _, profiles = environment
    first = profiles.create('Profile 001', 'Microsoft Edge')
    second = profiles.create('Profile 002', 'Google Chrome')
    manager = BrowserManager(db, profiles)

    async def run():
        started = set()
        both_started = asyncio.Event()
        release = asyncio.Event()

        async def delayed_launch(profile, bounds=None):
            started.add(profile.id)
            if len(started) == 2:
                both_started.set()
            await release.wait()

        with patch.object(manager, 'launch_and_open_dola', side_effect=delayed_launch):
            task = asyncio.create_task(manager.launch_all_and_open_dola([first, second]))
            await asyncio.wait_for(both_started.wait(), timeout=1)
            release.set()
            opened, failures = await task
        assert opened == [first, second]
        assert failures == []

    asyncio.run(run())


def test_configured_unpacked_extension_is_loaded_for_each_profile(environment, tmp_path):
    db, settings, profiles = environment
    extension = tmp_path / 'approved_extension'
    extension.mkdir()
    (extension / 'manifest.json').write_text('{"manifest_version": 3, "name": "Test Extension", "version": "1.0"}', encoding='utf-8')
    settings.save({'extension_folder': str(extension)})
    profile = profiles.create('Extension profile', 'Google Chrome')
    manager = BrowserManager(db, profiles)
    playwright = MagicMock(); context = MagicMock(); context.close = AsyncMock()
    playwright.chromium.launch_persistent_context = AsyncMock(return_value=context)
    manager.playwright = playwright

    async def run():
        with patch('app.browser_manager.detect_browser', return_value=Path('browser.exe')):
            await manager.launch(profile)

    asyncio.run(run())
    arguments = playwright.chromium.launch_persistent_context.call_args.kwargs['args']
    assert f'--load-extension={extension.resolve()}' in arguments


@pytest.mark.parametrize('browser,relative', [('Microsoft Edge', 'Microsoft/Edge/Application/msedge.exe'), ('Google Chrome', 'Google/Chrome/Application/chrome.exe')])
def test_windows_browser_detection(tmp_path, monkeypatch, browser, relative):
    executable = tmp_path / relative; executable.parent.mkdir(parents=True); executable.touch()
    monkeypatch.setenv('PROGRAMFILES', str(tmp_path))
    with patch('app.browser_manager.platform.system', return_value='Windows'):
        assert detect_browser(browser) == executable
